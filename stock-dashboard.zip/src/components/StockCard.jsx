export default function StockCard({ symbol, name, price, change }) {
  const isNegative = change.includes("-");
  return (
    <div className="bg-neutral-800 p-4 rounded-xl flex justify-between items-center">
      <div>
        <p className="text-sm opacity-70">{symbol}</p>
        <h3 className="font-semibold">{name}</h3>
      </div>
      <div className="text-right">
        <p className="font-semibold">{price}</p>
        <p className={isNegative ? "text-red-400" : "text-green-400"}>{change}</p>
      </div>
    </div>
  );
}
