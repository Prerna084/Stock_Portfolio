import StockCard from "../components/StockCard";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-neutral-900 text-white p-6">
      {/* Portfolio Balance */}
      <div className="bg-gradient-to-r from-green-600 to-green-400 rounded-2xl p-6 mb-8 shadow-lg">
        <h1 className="text-xl opacity-80">Value - Performance</h1>
        <p className="text-4xl font-extrabold mt-2">$228,00.47</p>
        <p className="text-sm mt-1 text-green-200">+ $3.21 (1.42%)</p>

        {/* Action Buttons */}
        <div className="flex gap-4 mt-4">
          <button className="bg-white/20 backdrop-blur px-4 py-2 rounded-xl text-sm">
            Trade
          </button>
          <button className="bg-white/20 backdrop-blur px-4 py-2 rounded-xl text-sm">
            Transactions
          </button>
          <button className="bg-white/20 backdrop-blur px-4 py-2 rounded-xl text-sm">
            Withdraw
          </button>
          <button className="bg-white/20 backdrop-blur px-4 py-2 rounded-xl text-sm">
            Deposit
          </button>
        </div>
      </div>

      {/* Watchlist */}
      <h2 className="text-lg font-semibold mb-4">Watchlist</h2>
      <div className="space-y-3">
        <StockCard symbol="VOO" name="Vanguard 500 ETF" price="45.57" change="+7.62%" />
        <StockCard symbol="NVDA" name="NVIDIA" price="47.57" change="+5.87%" />
        <StockCard symbol="MSTR" name="MicroStrategy" price="57.45" change="-1.42%" />
        <StockCard symbol="HOOD" name="Robinhood Markets" price="74.41" change="+4.76%" />
      </div>
    </div>
  );
}
